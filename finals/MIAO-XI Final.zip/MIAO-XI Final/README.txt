The .doc file and .pdf file have the same content, 
the .doc file enables track change to facilitate reviewing